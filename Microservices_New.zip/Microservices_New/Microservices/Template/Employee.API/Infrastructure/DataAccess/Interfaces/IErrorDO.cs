﻿
namespace Upscript.Services.Employee.API.DataAccess.Interfaces
{
    public interface IErrorDO
    {
            public int StatusCode { get; set; }
            public string Message { get; set; }
    }
}
