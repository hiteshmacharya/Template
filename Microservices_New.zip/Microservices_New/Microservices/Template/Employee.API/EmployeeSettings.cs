﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Upscript.Services.Employee.API
{
    public class EmployeeSettings
    {
        public string ConnectionString { get; set; }
    }
}
