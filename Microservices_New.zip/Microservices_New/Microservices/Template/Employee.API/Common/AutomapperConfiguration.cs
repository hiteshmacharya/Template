﻿using AutoMapper;

namespace Upscript.Services.Employee.API.Common
{
    public class AutomapperConfiguration:Profile
    {
        public AutomapperConfiguration()
        {
            //Write all the mapping here.
                
        }
    }
}
