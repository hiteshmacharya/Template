In Order to run Template Applications below are the prerequisites

1. MYSQL has to be installed locally

2. Run application through docker compose itself, so that RabbitMQ server also can be run as application requires RabbitMQ.

3. Make changes into Appsettings.json

4. Once application run through docker Compose file, you can check rabbitmq on url localhost:15672

 